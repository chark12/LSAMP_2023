# Guess the color game

Quick and dirty color guessing game. In a weak moment I promised my kids I would make a better game for them since the one they play on their iPad is riddled with ads and in-app purchases. [Play here](https://librarian.dev/color-heroes-game).

![](https://raw.githubusercontent.com/dermike/guess-the-color-game/master/screenshot/screenshot.jpg)

Superhero logos from [Speckyboy](https://speckyboy.com/freebie-the-flat-superheroes-villains-icon-set-100-icons-png-svg/) (Design by Freepik.com)

Sounds by [David McKee (ViRiX)](https://soundcloud.com/virix)
